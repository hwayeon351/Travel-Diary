package com.course.adddiary;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


public class AddDiaryActivity extends AppCompatActivity implements View.OnClickListener {
    private static final int PICK_FROM_CAMERA = 0;
    private static final int PICK_FROM_ALBUM = 1;

    private Uri mImageCaptureUri;
    private ImageView diaryPhoto;
    private Button image_upload_btn;
    private int id_view;

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_diary);



        final DBHelper dbHelper = new DBHelper(getApplicationContext(), "Diary.db", null, 1);

        final EditText d_time = (EditText) findViewById(R.id.diary_time);
        final EditText d_date = (EditText) findViewById(R.id.diary_date);

        // 날짜는 현재 날짜로 고정
        // 현재 시간 구하기
        long now = System.currentTimeMillis();
        Date date = new Date(now);

        // 출력될 포맷 설정
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        d_date.setText(simpleDateFormat.format(date));
        SimpleDateFormat simpleTimeFormat = new SimpleDateFormat("aa HH:mm");
        d_time.setText(simpleTimeFormat.format(date));

        diaryPhoto = (ImageView) this.findViewById(R.id.diary_image);
        diaryPhoto.setImageResource(R.drawable.image_icon);
        image_upload_btn = (Button)this.findViewById(R.id.image_upload_btn);
        image_upload_btn.setOnClickListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.adddiary_menu,menu);
        return true;
    }

    @Override
    public void onClick(View v){
        id_view = v.getId();
        if(v.getId() == R.id.image_upload_btn){
            DialogInterface.OnClickListener cameraListener = new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    doTakePhotoAction();
                }
            };
            DialogInterface.OnClickListener albumListener = new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    doTakeAlbumAction();
                }
            };
            DialogInterface.OnClickListener cancelListener = new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            };

            new AlertDialog.Builder(this)
                    .setTitle("업로드할 이미지를 선택하세요.")
                    .setPositiveButton("카메라",cameraListener)
                    .setNeutralButton("갤러리",albumListener)
                    .setNegativeButton("Cancel",cancelListener)
                    .show();
        }

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.action_save_btn:
                saveBtnOnClicked();
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }
    }
    public void saveBtnOnClicked() {
        final DBHelper dbHelper = new DBHelper(getApplicationContext(), "Diary.db", null, 1);

        EditText d_time = (EditText) findViewById(R.id.diary_time);
        EditText d_date = (EditText) findViewById(R.id.diary_date);
        EditText d_place = (EditText) findViewById(R.id.diary_place);
        EditText d_memo = (EditText)findViewById(R.id.diary_memo);


        String time = d_time.getText().toString();
        String date = d_date.getText().toString();
        String img_path = mImageCaptureUri.getPath();
        String place = d_place.getText().toString();
        String memo = d_memo.getText().toString();

        final TextView result = (TextView) findViewById(R.id.result);


        dbHelper.insert(time, date, img_path, place, memo);
        result.setText(dbHelper.getResult());

        Log.i("add",dbHelper.getResult());
        Log.i("image",img_path);

        Toast.makeText(getApplicationContext(), "Saved Diary", Toast.LENGTH_SHORT).show();
    }

    //카메라에서 사진 촬영
    public void doTakePhotoAction(){
        int permissionCheck = ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA);
        if (permissionCheck == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 0);
        }else{
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(intent,PICK_FROM_CAMERA);
        }
    }

    //앨범에서 이미지 가져오기
    public void doTakeAlbumAction(){
        //앨범호출
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType(android.provider.MediaStore.Images.Media.CONTENT_TYPE);
        startActivityForResult(intent,PICK_FROM_ALBUM);
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode != RESULT_OK)
            return;

        switch (requestCode){
            case PICK_FROM_ALBUM:
            {
                mImageCaptureUri = data.getData();
                String imagePath = mImageCaptureUri.getPath();
                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), mImageCaptureUri);
                    // Log.d(TAG, String.valueOf(bitmap));
                    diaryPhoto.setImageBitmap(bitmap);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
            }
            case PICK_FROM_CAMERA:
            {
                if(resultCode != RESULT_OK){
                    return;
                }
                mImageCaptureUri = data.getData();
                String imagePath = mImageCaptureUri.getPath();

                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), mImageCaptureUri);
                    // Log.d(TAG, String.valueOf(bitmap));
                    diaryPhoto.setImageBitmap(bitmap);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
            }

        }
    }

    @Override
    public void onBackPressed(){
        super.onBackPressed();
    }


}

